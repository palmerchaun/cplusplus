/*
Prime Example header
9/18/20
Seth Palmer
*/

#ifndef FUNCTIONS_H
#define FUNCTIONS_H

bool isPrime(int);
void listPrimes(int);

#endif
